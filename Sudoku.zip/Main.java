
package sudoku;




public class Main {

    public static void runTest() {
        
        Sudoku sudoku;
        
//        for(int i = 1; i <= 17; i++) {
//            sudoku = new Sudoku("fivestar" + i + ".txt");
//            sudoku.start(3);
//        }

//        for(int i = 1; i <= 12; i++) {
//            String fileName = "17-" + i + ".txt";
//            sudoku = new Sudoku(fileName);
//            System.out.println("Starting " + fileName);
//            sudoku.start(4);
//        }
        
        
        sudoku = new Sudoku("hardestinworld.txt"); //Select the hardest sudoku puzzle in the world
        sudoku.start(4);  //Start depth-limited search
        
    }
    
    public static void main(String[] args) {
        
        
        //Interactive filename
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Enter filename");
//        Sudoku sudoku = new Sudoku(scanner.nextLine());
//        sudoku.iterativeDeepeningSearch(0);
        runTest();
        
        
        
    }
    
    
}
